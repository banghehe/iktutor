NODEJS Drawing Demo  

It is a real time whiteboard collaborative free in HTML5  nodejs and socket.io library,
you can chat, draw, upload images and capture image
directly from your webcam



**** Demo on Heroku: https://vrobbi-nodedrawing.herokuapp.com/



